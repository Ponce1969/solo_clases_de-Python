#import usuario

#def guardar():
#    usuario.guardar() # sin injeccion de dependencias


#def guardar(entidad): # con injeccion de dependencias
#   entidad.guardar()
       
# conttuir un mini framework para injeccion de dependencias en el proximo video.

