#int() convierte a entero
#float() convierte a flotante
#str() convierte a cadena
#bool() convierte a booleano evalua si es verdadero o falso True o False
#list() convierte a lista
#tuple() convierte a tupla
#set() convierte a conjunto
#dict() convierte a diccionario

# bool() evalua en Folsy si es un string vacio, 0, lista vacia, tupla vacia, diccionario vacio, None.
# bool() evalua en True si es un string no vacio, 1, lista con elementos, tupla con elementos, diccionario con elementos, etc.

x= input("Introduce un número: ")


