nombre_curso =  "Ultimate Python"
nombre1 = "Ultimate Python"
NOMBRE_CURSO = "Ultimate Python"
Nombre_Curso = "Ultimate Python"
NoMbRe_CuRsO = "Ultimate Python"




print(nombre_curso, nombre1, NOMBRE_CURSO, Nombre_Curso, NoMbRe_CuRsO)

alunmos = 5000 # int
puntaje = 4.5 # float
publicado = True # bool (si)
publicado = False # bool (no)

