import math

# devolver numero mas cercano 
print(round(5.6))
print(round(5.4))
print(round(5.5))
print(abs(-77))
print(abs(55))

# funciones matematicas
print(math.ceil(5.6))# redondea hacia arriba
print(math.floor(5.6))# redondea hacia abajo
print(math.isnan(23))# devuelve true si es un numero y false si no lo es.
print(math.sqrt(9))# devuelve la raiz cuadrada de un numero
print(math.pow(2,3))# devuelve la potencia de un numero

#Python math https://www.w3schools.com/python/module_math.asp  https://docs.python.org/3/library/math.html