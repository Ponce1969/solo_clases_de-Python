numero = 2 # entero (int)
decimal = 2.5 # decimal (float)
imaginario = 2 + 2j # imaginario (complex)


numero = numero + 2 # forma larga de sumar 2 a numero.
numero += 2 # numero = numero + 2 (forma abreviada)


print(1 + 3) # suma
print(1 - 3) # resta
print(1 * 3) # multiplicacion
print(1 / 3) # division
print(1 // 3) # division entera
print(1 % 3) # modulo
print(2 ** 3) # potencia
print(2 ** 0.5) # raiz cuadrada


