curso = 'Ultimate Python"' # se puede usar comillas simples o dobles.
curso = "Ultimate \"Python\"" # se puede usar comillas simples o dobles.
curso = "Ultimate \nPython" # salto de linea.
curso = "Ultimate \tPython" # tabulacion.
curso = "Ultimate \\Python" # backslash.
curso = r"C:\Users\gonza\Documents\Python\Python\Python" # raw string, no interpreta los caracteres especiales.
print(curso)