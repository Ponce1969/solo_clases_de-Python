nombre = "Gonzalo"
apellido = "Ponce"
#nombre_completo = nombre + " " + apellido
nombre_completo = f"{nombre} {apellido}" # Forma recomendada de concatenar strings.
nombre_completo = f"{nombre[0]} {2 + 5}"
print(nombre_completo)
