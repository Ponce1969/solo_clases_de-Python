nombre_curso = "Ultimate Python"
descripcion_curso = """ 
Ultimate Python,
este curso contempla todos los detalles
que necesitas para aprender Python y encontrar 
un trabajao como programador.
 """ 
 
print(len(nombre_curso)) # cantidad de caracteres que tiene la variable.
print(nombre_curso[0]) # acceder a un caracter en especifico, siempre empieza en 0.
print(nombre_curso[-1]) # acceder al ultimo caracter de la variable.
print(nombre_curso[0:7]) # acceder a un rango de caracteres, siempre empieza en 0.
print(nombre_curso[0:]) # al no poner el segundo valor, se toma hasta el final.
print(nombre_curso[:7]) # al no poner el primer valor, se toma desde el inicio.
print(nombre_curso[:]) # al no poner ningun valor, se toma toda la variable. 



 