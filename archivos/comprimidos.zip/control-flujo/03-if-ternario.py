#edad = 15

# if edad > 17 :
 #   mensaje = "puedes ver la pelicula"
#else:
#    mensaje = "no puedes ver la pelicula"
    
#print(mensaje)


edad = 18
mensaje = "puedes ver la pelicula" if edad > 17 else "no puedes ver la pelicula"
print(mensaje)




