# quiero comprar una entrada al cine y ver si puedo entrar a verla.

#edad = 22
#if edad >= 18:#si la edad es mayor o igual a 18 años evalua en True o False.
#    print("Puedes entrar a ver la película")
#else:
#   print("No puedes entrar a ver la película") # identado con 4 espacios imporante.
    
    
    
#ejemplo 2 el orden de los factores si altera el producto.
# el codigo se lee de arriba hacia abajo y se ejecuta de arriba hacia abajo.
edad = 70
if edad > 65:
    print("puedes ver la pelicula con  super descuento")
elif edad > 54:
    print("puedes ver la pelicula con descuento")
elif edad > 17:
    print("puedes ver la pelicula")
else:
    print("no puedes ver la pelicula")    
    
    
    


    