edad = 25

if edad >= 15 and edad <= 65:   # if 15 <= edad <= 65: # otra forma de escribirlo mejor y mas corto.
    print("puedes entrar a la piscina")
else:
    print("no puedes entrar a la piscina")
    
 # de esta manera podemos encadenar comparaciones, y se evaluan de izquierda a derecha.
    