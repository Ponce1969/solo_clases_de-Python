#expresiones es algo que se evalua y se convierte en un valor

print(1 > 2) #False
print(1 < 2) #True
print(1 >= 2) #False
print(1 <= 2) #True
print(1 == 2) #False
print(1 == 1) #True
print(1 != 2) #True
print(1 != 1) #False


# Operadores lógicos
