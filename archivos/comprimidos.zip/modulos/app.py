# importaos desde usuarios.py la clase guardar, pagar_impuestos
from usuarios.acciones.utilidades import guardar, pagar_impuestos

# Llamamos a la funcion guardar
guardar()
pagar_impuestos()
# Ejecutamos el archivo app.py

# Modulo = archivo de python
# Paquete = carpeta que contiene modulos