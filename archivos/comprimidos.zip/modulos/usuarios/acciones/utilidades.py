#Usamos Modulos para separar el codigo en diferentes archivos
def guardar():
    print("Guardando usuario")
    
    
def pagar_impuestos():
    print("Pagando impuestos")