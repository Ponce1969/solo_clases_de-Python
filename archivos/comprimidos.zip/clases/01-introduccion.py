#aprendemos clases
#Clase: es el plano de construccion de un objeto , instancia de una clase.
#clase es un molde para crear objetos
#los objetos tienen atributos y metodos
#los atributos son variables y los metodos son funciones
#las clases se definen con la palabra reservada Class
#las clases se definen con la primera letra en mayuscula
#las clases pueden tener un constructor __init__
#el constructor se ejecuta automaticamente al crear un objeto
#el constructor puede recibir parametros
#self es un parametro que hace referencia al objeto creado
#para crear un objeto se utiliza el nombre de la clase y parentesis
#para acceder a un atributo se utiliza la notacion del punto
#para llamar un metodo se utiliza la notacion del punto y parentesis
mensaje = "Hola mundo"
print(type(mensaje)) #<class 'str'>

#Clase: Humano
# objeto: Juan, Pedro, Maria
# atributos: nombre, edad, estatura, peso, color de piel
# metodos: caminar, correr, comer, dormir, estudiar, trabajar


