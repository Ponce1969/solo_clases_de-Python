# iterar sobre las listas
mascotas = ['perro', 'gato', 'perico', 'pez']
for mascota in mascotas:
    print(mascota)#nos da todas las mascotas.
    
#funcion enumerate, nos da el indice y el nombre de la tupla.
for  mascota in enumerate(mascotas):
    print( mascota[0])#nos da el indice de la tupla.
    
    
    