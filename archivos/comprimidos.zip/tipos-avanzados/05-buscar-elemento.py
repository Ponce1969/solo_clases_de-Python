mascotas = ['perro', 'gato', 'perico', 'pez']

print(mascotas.count('perro'))#nos da el numero de veces que se repite el elemento = 1
if 'perro' in mascotas:
    print(mascotas.index('perro'))#nos da el indice del elemento que buscamos = 0 .


